import { forwardMail } from "../helpers/sso-helper";
import CONFIG from "../config";

let reportBtn, cancelBtn, statusEl, progressContainer, progressMsg;

// Get DOM elements immediately 
document.addEventListener("DOMContentLoaded", () => {
  const confirmEl = document.getElementById("confirmText");
  if (confirmEl) {
    confirmEl.innerText = CONFIG.UI.CONFIRM_DIALOG;
  }

  reportBtn = document.getElementById("reportBtn");
  cancelBtn = document.getElementById("cancelBtn");
  statusEl = document.getElementById("status");
  progressContainer = document.getElementById("progressContainer");
  progressMsg = document.getElementById("progressMsg");

  // Disable report button until Office is ready
  if (reportBtn) {
    reportBtn.disabled = true;
    reportBtn.classList.add("btn-loading");
  }
});

Office.onReady((info) => {
  if (info.host === Office.HostType.Outlook) {
    reportBtn?.addEventListener("click", run);
    cancelBtn?.addEventListener("click", closeTaskPane);

    // Enable button once Office is ready
    if (reportBtn) {
      reportBtn.disabled = false;
      reportBtn.classList.remove("btn-loading");
    }
  }
});

export async function run() {
  reportBtn.disabled = true;
  reportBtn.classList.add("btn-loading");

  showProgress(CONFIG.UI.REQUEST_PERMISSIONS);

  try {
    const item = Office.context.mailbox.item;

    const messageId = Office.context.mailbox.convertToRestId(
      item.itemId,
      Office.MailboxEnums.RestVersion.v2_0
    );

    await forwardMail(
      messageId,
      handleResponse,
      () => {
        showProgress(CONFIG.UI.PROCESSING);
      }
    );

  } catch (err) {
    console.error(err);
    hideProgress();
    show(CONFIG.UI.FAILED_TO_REPORT);
    resetReportButton();
  }
}

async function handleResponse(response) {
  console.log("Response received:", response);

  hideProgress();
  resetReportButton();

  if (response.forward?.success) {
    show(CONFIG.UI.SUCCESS_MESSAGE);
  }
  else {
    const err = response.forward?.error;
    if (err) {
      show(`${CONFIG.UI.FAILED_TO_REPORT} ${err.replace(/^❌\s*/, "")}`);
    } else {
      show(CONFIG.UI.FAILED_TO_REPORT);
    }
  }

  setTimeout(() => {
    closeTaskPane();
  }, 3500);
}

// UI helpers
function resetReportButton() {
  reportBtn.disabled = false;
  reportBtn.classList.remove("btn-loading");
}

function show(msg) {
  if (statusEl) {
    statusEl.innerText = msg;
  }
}

function showProgress(msg) {
  if (progressContainer) {
    progressContainer.style.display = "block";
  }
  if (progressMsg) {
    progressMsg.innerText = msg;
  }
}

function hideProgress() {
  if (progressContainer) {
    progressContainer.style.display = "none";
  }
}

function closeTaskPane() {
  Office.context.ui.closeContainer();
}

